# File Handling

# key function - open()
# 2 parameters - filename, mode
# r - read, file doesnot exist show error - open ('fileee.txt')=open ('filee.txt',r)
# w - write, file doesnot exist => create that file. file-exists => write the content.
# x - append - apends the content-file doesnot exist => create that file.file-exists => append the content
# f = append-apends the content - file doesnot exist => create that file.file-exist => append the content

# for open file
f = open("demo.txt")
f=open("demo.txt", "w")
f.write("name:Vivek password:1234")

f1=open("demo1.txt","w")
f1=open("demo1.txt","a")
f1.write("name:Vivek password:1234")

# Read file and print
f1=open('demo1.txt')
print(f1.read())

# for Readline
f=open("demo.txt")
f=open("demo.txt","a")
f.write("name:Elango password:456789")
f=open("demo.txt")
print(f.readline(), end='')
print(f.readline())
print(f.readline(5))

# f3=open('demo2.txt',"x")
f4=open('demo2.txt')
f4=open("demo2.txt","a")
f4.write("name:karthi password:17849")
f4=open("demo2.txt")
print(f4.readline())

# for rewrite
# f4=open("demo2.txt","w")
# f4.write("name:karthi password:17849")
# print(f4.readline())

print(f.close())
print(f1.close())
print(f4.close())





